import UIKit
print("This program does my laundry - I wish!")
print("") //break

//variables
var containerOfPants: [String] = ["unwashed shorts", "unwashed sweats pants", "unwashed jeans"]
var containerOfShirts: [String] = ["unwashed spartan shirt", "unwashed gym tank", "unwashed t-shirt"]
var containerOfSocks: [String] = ["unwashed tall socks", "unwashed short socks"]

//closures
var washItem = { (item:String)-> String in
    var clone = String(item) // variable to hold items value as I cannont change it (need to look into this)
    if clone.contains("unwashed"){
        clone = clone.replacingOccurrences(of: "unwashed", with: "clean")
    }
    return clone
}

// functions
func washArray(table:Array<String>) -> Array<String> {
    print("washing these - \(table)")
    print("")//break
    var cleanContainer:[String] = []
    for value in table {
        let newValue = washItem(value)
        cleanContainer.append(newValue)
    }
    return cleanContainer
}

// func calls & printing
let cleanPants = washArray(table: containerOfPants)
let cleanShirts = washArray(table: containerOfShirts)
let cleanSock = washArray(table: containerOfSocks)

print("")//break
print("washing completed - results below")
print(cleanShirts)
print(cleanPants)
print(cleanSock)
