import UIKit
print("lab project: blackhawks")

// player data in dictionaries
let players = [26:"Evan Barrat", 13:"Henrik Borgstrom", 20:"Brett Connolly", 38:"Brandon Hagel"]
let age = [26:22, 13:24, 20:29, 38:23]
let height = [26:72, 13:75, 20:75, 38:71] //height in inches
let birthMonth = [26:"Feb", 13:"Aug", 20:"May", 38:"Aug"]
let country = [26:"USA", 13:"FIN", 20:"CAN", 38:"CAN"]

// Sorting by AGE
print("----- Players by age -----")
let sortedByAge = age.sorted {
    return $0.1 < $1.1
}
for (key, value) in sortedByAge {
    print("Name: \(String(describing: players[key])) Age: \(value)")
}
print(" ")

// Sorting by COUNTRY
print("----- Players by country -----")
let sortedByCountry = country.sorted {
    return $0.1 < $1.1
}
for (key, value) in sortedByCountry {
    print("Name: \(String(describing: players[key])) Country: \(value)")
}
print(" ")

// Average age of players
print("----- Averages & Other Stats -----")
var sum = Int(0)
for (_, value) in age {
    sum = sum + value
}
let averageAge = Double(sum/age.count) // mathmatic formula to get the average
print("Average age of all players:\(averageAge)")

//Average height of players
sum = Int(0)
for (_, value) in height {
    sum = sum + value
}
let averageHeight = Double(sum/height.count)
print("Average height of all players: \(averageHeight) inches")

// Average bith month
var availableMonths = ["Feb":0, "Aug":0, "May":0]
for (_, value) in birthMonth {
    if (availableMonths[value] != nil) {
        availableMonths[value] = availableMonths[value]! + 1
    }
}
print("")
print("Month most players were born on is below.")
print(availableMonths.max { a, b in a.value < b.value } as Any)
