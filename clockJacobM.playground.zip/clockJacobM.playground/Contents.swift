import UIKit
print("clock app is running")
// variables & constants
var dayNight = ("PM")
var sec = Int(55)
var min = Int(59)
var hr = Int(12)

var clockRunning = true

while clockRunning == true {
    sleep(1)
    sec = sec + 1
    // value increases
    if sec >= 60 {
        sec = 0
        min = min + 1
    }
    if min >= 60 {
        min = 0
        hr = hr + 1
    }
    
    // clocktime formatting
    if hr == 12 && min == 0  && sec == 0{
        if dayNight == ("PM"){
            dayNight = ("AM")
        }
        else {
            dayNight = ("PM")
        }
    }
    if hr == 13 { // 13 indicates we need to revert back to 1
        hr = 1
    }
    // output display
    print("clock: \(hr):\(min):\(sec)\(dayNight)")
}

