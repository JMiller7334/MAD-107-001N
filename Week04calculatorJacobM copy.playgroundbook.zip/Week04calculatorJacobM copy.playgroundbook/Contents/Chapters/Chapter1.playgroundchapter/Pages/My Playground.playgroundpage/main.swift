import Foundation
//variables
var addAnswer = 5
var subtractAnswer = 20
var multiplyAnswer = 5
var divideAnswer = 30
var percentAnswer = 12.00

//math handling
addAnswer = addAnswer + 5
subtractAnswer = subtractAnswer - 10
multiplyAnswer = multiplyAnswer * 4
divideAnswer = divideAnswer / 3
percentAnswer = percentAnswer / 30.00; percentAnswer = percentAnswer * 100

//answer printing
print("5+5=\(addAnswer)")
print("20-10=\(subtractAnswer)")
print("5*4=\(multiplyAnswer)")
print("30/3=\(divideAnswer)")
print("12% of 30 is \(percentAnswer)%")
