import UIKit

print("this thing sorts video games by played")

//Collections
var gamesPlayed = ["Mass Effect": "not played", "Sonic Adventure 2": "played", "Paper Mario": "played", "TombRaider": "played", "Forza": "not played",]

var playedTitle = [String]()
var notPlayedTitle = [String]()

//Sorting
for (k, v) in gamesPlayed { //k=key, v=value
    if (v == "played") {
        playedTitle.append(k)
    }
    else {
        notPlayedTitle.append(k)
    }
}

// display
print("----- games played below -----")
for element in playedTitle {
    print(element)
}

print("----- games not played below ------")
for element in notPlayedTitle {
    print(element)
}
