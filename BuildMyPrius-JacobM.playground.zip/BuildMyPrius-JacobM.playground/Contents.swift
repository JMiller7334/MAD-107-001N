import UIKit
print("Build My Prius Program")

// Arrays hold additonal product option info, prices, etc and are accessed via
// rawValue from enums - new options should be tacked onto the end of these arrays/enums

let modelMPG:[String] = ["58/53", "54/50", "51/47"]// Model MPG
let modelPrice:[Double] = [24525.00, 25735.00, 27135.00]//Model Price
let modelName:[String] = ["L Eco", "LE", "LE AWD e"]
enum optionsModel: Int { // rawValues refer directly to index at which their data is stored in corresponding array
    case l_Eco = 0
    case LE = 1
    case LE_AWDe = 2
}

let exteriorPrice:[Double] = [0.00, 425.00, 0.00]
let exteriorName:[String] = ["Electric Storm Blue", "Supersonic Red", "Midnight Black Metallic"]
enum optionsExterior: Int {
    case blue = 0
    case red = 1
    case black = 2
}

let InteriorNames:[String] = ["Moonstone Fabric", "Black Fabric", "Harvest Beige Fabric"]
enum optionsInterior:Int {
    case moonStone = 0
    case black = 1
    case beige = 2
}

let accessoryPrice:[Double] = [796.00, 299.00, 65.00]
let accessoryNames:[String] = ["15' 10 Spoke Alloy Wheels", "Aero Side Splitter", "Alloy Wheel Locks"]
enum optionsAccessories:Int{
    case alloyWheels = 0
    case SideSplitter = 1
    case wheelLocks = 2
}

//classes
class priusOrder{
    let modelIndex: Int
    let exteriorIndex: Int
    let interiorIndex: Int
    let accessoriesIndex:[Int]
    
    func printOrder(){
        
        print("")
        print("---------- Order Summary ---------")
        print("Model: \(modelName[self.modelIndex]) +$\(String(format: "%g",modelPrice[self.modelIndex]))")
        print("Exterior Color: \(exteriorName[self.exteriorIndex]) +$\(String(format: "%g",exteriorPrice[self.exteriorIndex]))")
        print("Interior Color: \(InteriorNames[self.interiorIndex]) + $0.00")
        print("")
        print("------- Added Accessories -------")
        var subtotal = 0.00 + modelPrice[self.modelIndex] + exteriorPrice[self.exteriorIndex]
        if accessoriesIndex.isEmpty{
            print("no accessoires chosen + $0.00")
        }
        else{
            for (_, v) in accessoriesIndex.enumerated(){
                subtotal = subtotal + accessoryPrice[v]
                print("Accessory: \(accessoryNames[v]) +$\(String(format: "%g",accessoryPrice[v]))")
            }
        }
        print("")
        print("subtotal:$\(String(format: "%g",subtotal))")
    }
 
    init(ModelIndex:Int, ExteriorIndex:Int, InteriorIndex:Int, AccessoriesIndex:[Int]) {
        self.modelIndex = ModelIndex
        self.exteriorIndex = ExteriorIndex
        self.interiorIndex = InteriorIndex
        self.accessoriesIndex = AccessoriesIndex
    }
}

//Array to pass in for chosen accessories
let order1Accessories:[Int] = [optionsAccessories.SideSplitter.rawValue, optionsAccessories.alloyWheels.rawValue]
var order1 = priusOrder(ModelIndex: optionsModel.LE_AWDe.rawValue, ExteriorIndex: optionsExterior.red.rawValue, InteriorIndex: optionsInterior.moonStone.rawValue, AccessoriesIndex: order1Accessories)
order1.printOrder()

let order2Accesories = [Int]()
var order2 = priusOrder(ModelIndex: optionsModel.l_Eco.rawValue, ExteriorIndex: optionsExterior.black.rawValue, InteriorIndex: optionsInterior.black.rawValue, AccessoriesIndex: order2Accesories)
order2.printOrder()
