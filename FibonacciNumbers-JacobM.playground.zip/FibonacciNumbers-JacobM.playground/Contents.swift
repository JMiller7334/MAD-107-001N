import UIKit
// Fibonacci formula: N1+N2=N3; N1=N2, N2=N3; repeat
//ie: 1, 1,2, 3,5, 8
//ie:n1+n2=n3

print("Fibonacci numbers")
var n1 = Int(1)
var n2 = Int(1)
var n3 = Int(0)

var belowThousand = true

// functions
func getFibonacci(){
    n3 = (n1 + n2)
    n1 = n2
    n2 = n3
    print("\(n1) \(n2)")
    if(n3 > 1000){
        print("maximum limit exceeded; stopping")
        belowThousand = false
    }
}

// loop
while (belowThousand == true){
    sleep(1)
    getFibonacci()
}
